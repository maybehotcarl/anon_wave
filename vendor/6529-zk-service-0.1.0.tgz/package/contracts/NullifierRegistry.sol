// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

/**
 * @title NullifierRegistry
 * @notice Shared on-chain nullifier tracking for all 6529 ZK proof types.
 *         Allows multiple apps (marketplace, gating, voting) to track nullifiers
 *         independently via (proofType, appId, nullifierHash) namespacing.
 */
contract NullifierRegistry {
    // proofType => appId => nullifierHash => used
    mapping(bytes32 => mapping(bytes32 => mapping(bytes32 => bool)))
        public usedNullifiers;

    // Admin
    address public owner;
    mapping(address => bool) public authorizedCallers;

    event NullifierUsed(
        bytes32 indexed proofType,
        bytes32 indexed appId,
        bytes32 indexed nullifierHash,
        bytes32 commitmentHash
    );

    event CallerAuthorized(address indexed caller);
    event CallerRevoked(address indexed caller);

    modifier onlyOwner() {
        require(msg.sender == owner, "Not owner");
        _;
    }

    modifier onlyAuthorized() {
        require(
            msg.sender == owner || authorizedCallers[msg.sender],
            "Not authorized"
        );
        _;
    }

    constructor() {
        owner = msg.sender;
    }

    /**
     * @notice Check if a nullifier has been used
     */
    function isNullifierUsed(
        bytes32 proofType,
        bytes32 appId,
        bytes32 nullifierHash
    ) external view returns (bool) {
        return usedNullifiers[proofType][appId][nullifierHash];
    }

    /**
     * @notice Mark a nullifier as used (only callable by authorized contracts)
     */
    function markNullifierUsed(
        bytes32 proofType,
        bytes32 appId,
        bytes32 nullifierHash,
        bytes32 commitmentHash
    ) external onlyAuthorized {
        require(
            !usedNullifiers[proofType][appId][nullifierHash],
            "Nullifier already used"
        );

        usedNullifiers[proofType][appId][nullifierHash] = true;

        emit NullifierUsed(proofType, appId, nullifierHash, commitmentHash);
    }

    /**
     * @notice Authorize a contract to mark nullifiers
     */
    function authorizeCaller(address caller) external onlyOwner {
        authorizedCallers[caller] = true;
        emit CallerAuthorized(caller);
    }

    /**
     * @notice Revoke a contract's authorization
     */
    function revokeCaller(address caller) external onlyOwner {
        authorizedCallers[caller] = false;
        emit CallerRevoked(caller);
    }

    /**
     * @notice Transfer ownership
     */
    function transferOwnership(address newOwner) external onlyOwner {
        require(newOwner != address(0), "Invalid address");
        owner = newOwner;
    }
}
