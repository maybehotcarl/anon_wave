pragma circom 2.1.0;

// Any Card Proof Circuit (Production — depth=20)
//
// Proves "I hold at least one Meme card" without revealing which card
// or the wallet address. Reuses the card_ownership Merkle tree.
//
// Public signals (3): merkleRoot, nullifierHash, commitmentHash
// Private signals: address, cardId, balance, nonce, merklePathElements, merklePathIndices

include "node_modules/circomlib/circuits/poseidon.circom";
include "node_modules/circomlib/circuits/comparators.circom";
include "node_modules/circomlib/circuits/bitify.circom";
include "../lib/merkle-tree-checker.circom";

template AnyCardProof(merkleDepth) {
    // PUBLIC INPUTS
    signal input merkleRoot;
    signal input nullifierHash;
    signal input commitmentHash;

    // PRIVATE INPUTS
    signal input address;
    signal input cardId;
    signal input balance;
    signal input nonce;
    signal input merklePathElements[merkleDepth];
    signal input merklePathIndices[merkleDepth];

    // 1. Merkle Tree Membership: leaf = Poseidon(address, cardId, balance)
    //    Same leaf structure as card_ownership tree
    component leafHasher = Poseidon(3);
    leafHasher.inputs[0] <== address;
    leafHasher.inputs[1] <== cardId;
    leafHasher.inputs[2] <== balance;
    signal leaf <== leafHasher.out;

    component merkleChecker = MerkleTreeChecker(merkleDepth);
    merkleChecker.leaf <== leaf;
    merkleChecker.merkleRoot <== merkleRoot;
    for (var i = 0; i < merkleDepth; i++) {
        merkleChecker.pathElements[i] <== merklePathElements[i];
        merkleChecker.pathIndices[i] <== merklePathIndices[i];
    }

    // 2. Balance >= 1 (must own at least one)
    component gte = GreaterEqThan(64);
    gte.in[0] <== balance;
    gte.in[1] <== 1;
    gte.out === 1;

    // 3. Nullifier: Poseidon(address, nonce, merkleRoot)
    //    NO cardId — same wallet always gets same nullifier regardless of card picked
    component nullifierGenerator = Poseidon(3);
    nullifierGenerator.inputs[0] <== address;
    nullifierGenerator.inputs[1] <== nonce;
    nullifierGenerator.inputs[2] <== merkleRoot;
    nullifierHash === nullifierGenerator.out;

    // 4. Commitment: Poseidon(address, nonce)
    component commitmentGenerator = Poseidon(2);
    commitmentGenerator.inputs[0] <== address;
    commitmentGenerator.inputs[1] <== nonce;
    commitmentHash === commitmentGenerator.out;
}

component main {public [merkleRoot, nullifierHash, commitmentHash]} = AnyCardProof(20);
