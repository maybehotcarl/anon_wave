pragma circom 2.1.0;

// TDH Range Proof Circuit (Test — depth=10, ~1K addresses)

include "node_modules/circomlib/circuits/poseidon.circom";
include "node_modules/circomlib/circuits/bitify.circom";
include "../lib/merkle-tree-checker.circom";
include "../lib/range-proof.circom";

template TDHRangeProof(merkleDepth) {
    signal input merkleRoot;
    signal input bucketMin;
    signal input bucketMax;
    signal input nullifierHash;
    signal input commitmentHash;

    signal input address;
    signal input tdhAmount;
    signal input nonce;
    signal input merklePathElements[merkleDepth];
    signal input merklePathIndices[merkleDepth];

    component leafHasher = Poseidon(2);
    leafHasher.inputs[0] <== address;
    leafHasher.inputs[1] <== tdhAmount;
    signal leaf <== leafHasher.out;

    component merkleChecker = MerkleTreeChecker(merkleDepth);
    merkleChecker.leaf <== leaf;
    merkleChecker.merkleRoot <== merkleRoot;
    for (var i = 0; i < merkleDepth; i++) {
        merkleChecker.pathElements[i] <== merklePathElements[i];
        merkleChecker.pathIndices[i] <== merklePathIndices[i];
    }

    component rangeChecker = RangeProof(64);
    rangeChecker.in <== tdhAmount;
    rangeChecker.min <== bucketMin;
    rangeChecker.max <== bucketMax;
    rangeChecker.out === 1;

    component nullifierGenerator = Poseidon(3);
    nullifierGenerator.inputs[0] <== address;
    nullifierGenerator.inputs[1] <== nonce;
    nullifierGenerator.inputs[2] <== merkleRoot;
    nullifierHash === nullifierGenerator.out;

    component commitmentGenerator = Poseidon(4);
    commitmentGenerator.inputs[0] <== address;
    commitmentGenerator.inputs[1] <== tdhAmount;
    commitmentGenerator.inputs[2] <== nonce;
    commitmentGenerator.inputs[3] <== bucketMin;
    commitmentHash === commitmentGenerator.out;
}

component main {public [merkleRoot, bucketMin, bucketMax, nullifierHash, commitmentHash]} = TDHRangeProof(10);
