// SPDX-License-Identifier: GPL-3.0
/*
    Copyright 2021 0KIMS association.

    This file is generated with [snarkJS](https://github.com/iden3/snarkjs).

    snarkJS is a free software: you can redistribute it and/or modify it
    under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.

    snarkJS is distributed in the hope that it will be useful, but WITHOUT
    ANY WARRANTY; without even the implied warranty of MERCHANTABILITY
    or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public
    License for more details.

    You should have received a copy of the GNU General Public License
    along with snarkJS. If not, see <https://www.gnu.org/licenses/>.
*/

pragma solidity >=0.7.0 <0.9.0;

contract Groth16Verifier {
    // Scalar field size
    uint256 constant r    = 21888242871839275222246405745257275088548364400416034343698204186575808495617;
    // Base field size
    uint256 constant q   = 21888242871839275222246405745257275088696311157297823662689037894645226208583;

    // Verification Key data
    uint256 constant alphax  = 20491192805390485299153009773594534940189261866228447918068658471970481763042;
    uint256 constant alphay  = 9383485363053290200918347156157836566562967994039712273449902621266178545958;
    uint256 constant betax1  = 4252822878758300859123897981450591353533073413197771768651442665752259397132;
    uint256 constant betax2  = 6375614351688725206403948262868962793625744043794305715222011528459656738731;
    uint256 constant betay1  = 21847035105528745403288232691147584728191162732299865338377159692350059136679;
    uint256 constant betay2  = 10505242626370262277552901082094356697409835680220590971873171140371331206856;
    uint256 constant gammax1 = 11559732032986387107991004021392285783925812861821192530917403151452391805634;
    uint256 constant gammax2 = 10857046999023057135944570762232829481370756359578518086990519993285655852781;
    uint256 constant gammay1 = 4082367875863433681332203403145435568316851327593401208105741076214120093531;
    uint256 constant gammay2 = 8495653923123431417604973247489272438418190587263600148770280649306958101930;
    uint256 constant deltax1 = 12779474482131646274312700851512008394989661843397519075291171247413575950496;
    uint256 constant deltax2 = 20651609803772201450925144959005721203540086325880898250299260697146669497362;
    uint256 constant deltay1 = 3795632535453077167733620464540786661230374380003264159459563944247451257634;
    uint256 constant deltay2 = 20136037069922201808915039117661016454020562080803407612968898067285529539006;

    
    uint256 constant IC0x = 515751120023389814400485564034628541296739239472907899650438915353164845768;
    uint256 constant IC0y = 18101796594997781548604556171677928934818571562243713021855299156587641631687;
    
    uint256 constant IC1x = 14116417177747376850553035542165335158562415506470344940634439962072026450063;
    uint256 constant IC1y = 10409748059313245709240226399539990119847388627954394295780883242276471768308;
    
    uint256 constant IC2x = 10821564656865865543642215402328106539184228710684919935808224917328242986035;
    uint256 constant IC2y = 17214643336112877192564516810336260626682784998887512646301666635516134061197;
    
    uint256 constant IC3x = 7906885651371002557789745455531651410653867807021652153714699734174017533913;
    uint256 constant IC3y = 17759974275652160962810424009744952194712206823896463249847876101196020365296;
    
    uint256 constant IC4x = 810760836382949926553070495285747598385854963832310541638687811886452033747;
    uint256 constant IC4y = 12904664956357723066240901308610362037811701874229121566099797143406032608252;
    
    uint256 constant IC5x = 10812438342124685668117955818926746773539713199025903783457675029935423890349;
    uint256 constant IC5y = 3480162456047096778542253364681572342049092502989086567124600222715656020175;
    
    uint256 constant IC6x = 4026959842777311561474205361219467796970454389346474528807909540877723979634;
    uint256 constant IC6y = 6118139085979320760607350905386204492335634845926762085808232458494984571620;
    
    uint256 constant IC7x = 7154905851495639856132628781502750522398785271794357799632682998813959287112;
    uint256 constant IC7y = 249147635203654937087907018704592035584546141290548558621947707574381340583;
    
    uint256 constant IC8x = 14765233621184967174983848611880918749440620036380555578513398021428211245674;
    uint256 constant IC8y = 14326011674339953095825061381058529831971563406385184569419114182835542042738;
    
    uint256 constant IC9x = 8233819178140637534329902896325788304450596349393660063111617823561226220342;
    uint256 constant IC9y = 20850149647162251027786560477186084593387414155838247423072648630306199377991;
    
    uint256 constant IC10x = 11088284014417788605355542879459660262157528420056568142779709148040914139685;
    uint256 constant IC10y = 11413292540920477926794537967913223450743112344423284105271732802999917667587;
    
    uint256 constant IC11x = 537304542135873818179202565262392784143461590130092039927212349089868188595;
    uint256 constant IC11y = 12038834543553097515450996643495682031936342374467974847456501641100726338614;
    
    uint256 constant IC12x = 9126596701691852899590757887787383944311900153828885007631700203900266072059;
    uint256 constant IC12y = 19124844651566302462458024657365120373823730142898633311035353280326012856813;
    
    uint256 constant IC13x = 5639226510911932571750617071628635231999194501879882103527868075475798502945;
    uint256 constant IC13y = 12767876581427898905253532026286554798291681739814241497599349027175167325273;
    
    uint256 constant IC14x = 9477385020939149380331004100606185233493499423416398253220825022566074027637;
    uint256 constant IC14y = 5425266453227341689733162883501124822727416506077430729689487271056809507441;
    
    uint256 constant IC15x = 12397954488228425724782248973167008046907947485699812295460338554503276273601;
    uint256 constant IC15y = 17174227077078409208440523590788102141040014078160601969116297880852289615628;
    
    uint256 constant IC16x = 9637897426965900101289529754834394596647232992828864359051768885059035303072;
    uint256 constant IC16y = 20609113345677026425151789786333155004896156168237995616806553410189396863023;
    
    uint256 constant IC17x = 17750768850525140185036190307736441166294158117219314298523477921686931796520;
    uint256 constant IC17y = 760326207411319724862026029347702519728991216403783341297488101937489532401;
    
    uint256 constant IC18x = 17393295811707686137715581948633904876082596630726283992352741331406659623603;
    uint256 constant IC18y = 13659276141088938676042358127330969421935796090637079250403481966970075372777;
    
    uint256 constant IC19x = 1383497037535758154575072069316324655805099357885184728979135851071414231264;
    uint256 constant IC19y = 7743425531945530288895128900993605502433975141419870540702077377620338384606;
    
    uint256 constant IC20x = 1560865910634875554339085853798850330269981136619798874157474041373977692414;
    uint256 constant IC20y = 13802243890274883914471633934606653925047395095455474462187540697046524496561;
    
    uint256 constant IC21x = 11378264731403396320668035116661922509073886326682449663306928222127577581395;
    uint256 constant IC21y = 20324747031159658897659516750853570331830400473441474314896108317066092319464;
    
    uint256 constant IC22x = 15107559514370870391245443740437792030018824863714161132923038454512492255319;
    uint256 constant IC22y = 7841981063195197708733256181417025858231972502593056206155248376167800069503;
    
    uint256 constant IC23x = 20789146474438425593224201377682709815885037100604424463933787995463933847928;
    uint256 constant IC23y = 18641172878114819771195975080233960598733984838416978550451121279908993506381;
    
    uint256 constant IC24x = 2797592544386219009532083802079459993431080540967435945926817431164441019007;
    uint256 constant IC24y = 4550066546967396461692455514075593220884648111178466602223156290992169402749;
    
    uint256 constant IC25x = 11463526838008980867841493516738803956715722323801183200942153883407035059045;
    uint256 constant IC25y = 13511035992842447233264053084453531018405942799385546006382401400872084381505;
    
    uint256 constant IC26x = 14234717450232580361382396588210638775190603002984689720615310618495318457114;
    uint256 constant IC26y = 12525429738743553532001920947116522301563910913940136322105907477023343177962;
    
    uint256 constant IC27x = 3212792029188591282266776870074923843924950272999683736360725822724991981112;
    uint256 constant IC27y = 5073223996268996488206331440965270634948978119477770105934782631327398562436;
    
    uint256 constant IC28x = 10476527149747314531686285902294257661350690300703384623641847567600724284060;
    uint256 constant IC28y = 20371146978501667985174559420005295814548111742300215428471510076015365717066;
    
    uint256 constant IC29x = 11756989718768629823969405600913810882109231834688473467181782520559934708082;
    uint256 constant IC29y = 12742814704955430736206646207408706375725575890494077444522086493378296530316;
    
    uint256 constant IC30x = 1035273256099517692423196580711786585030502469926615208032108085299222440643;
    uint256 constant IC30y = 2088304415443336022983199990126724603740062586848182273408609847241433737670;
    
    uint256 constant IC31x = 11480092338645840129125076890476326653385382882050362728251750990040816327533;
    uint256 constant IC31y = 13253955659983256948936466751739537820513180145998005860086028577583517226106;
    
    uint256 constant IC32x = 20459788915386128638071469371860304986081171639187850311602594376572522015949;
    uint256 constant IC32y = 19123459132052854985519643131761560236238288874731054019954939597738881899954;
    
    uint256 constant IC33x = 12397985508099176344812683662622174687780220451157478141421717947481902687247;
    uint256 constant IC33y = 640083047772991453201724470879816930127790158564005560747657655928326803552;
    
    uint256 constant IC34x = 4907519207672804424488610972093330747881212352787994136259573370255686706597;
    uint256 constant IC34y = 3317249561849167981548013592048315995820254349050972349726165830827063750926;
    
    uint256 constant IC35x = 5120938890069592795892021552772164925293901193121185269209416336843151174755;
    uint256 constant IC35y = 3281670094053109350417106556286776989210477048589434607018088497758220425673;
    
    uint256 constant IC36x = 1148781047216759242200606527743055078260164509921420329006207361747037676212;
    uint256 constant IC36y = 11285136973683980625809548415811885376355106281412835814181704993209573955614;
    
 
    // Memory data
    uint16 constant pVk = 0;
    uint16 constant pPairing = 128;

    uint16 constant pLastMem = 896;

    function verifyProof(uint[2] calldata _pA, uint[2][2] calldata _pB, uint[2] calldata _pC, uint[36] calldata _pubSignals) public view returns (bool) {
        assembly {
            function checkField(v) {
                if iszero(lt(v, r)) {
                    mstore(0, 0)
                    return(0, 0x20)
                }
            }
            
            // G1 function to multiply a G1 value(x,y) to value in an address
            function g1_mulAccC(pR, x, y, s) {
                let success
                let mIn := mload(0x40)
                mstore(mIn, x)
                mstore(add(mIn, 32), y)
                mstore(add(mIn, 64), s)

                success := staticcall(sub(gas(), 2000), 7, mIn, 96, mIn, 64)

                if iszero(success) {
                    mstore(0, 0)
                    return(0, 0x20)
                }

                mstore(add(mIn, 64), mload(pR))
                mstore(add(mIn, 96), mload(add(pR, 32)))

                success := staticcall(sub(gas(), 2000), 6, mIn, 128, pR, 64)

                if iszero(success) {
                    mstore(0, 0)
                    return(0, 0x20)
                }
            }

            function checkPairing(pA, pB, pC, pubSignals, pMem) -> isOk {
                let _pPairing := add(pMem, pPairing)
                let _pVk := add(pMem, pVk)

                mstore(_pVk, IC0x)
                mstore(add(_pVk, 32), IC0y)

                // Compute the linear combination vk_x
                
                g1_mulAccC(_pVk, IC1x, IC1y, calldataload(add(pubSignals, 0)))
                
                g1_mulAccC(_pVk, IC2x, IC2y, calldataload(add(pubSignals, 32)))
                
                g1_mulAccC(_pVk, IC3x, IC3y, calldataload(add(pubSignals, 64)))
                
                g1_mulAccC(_pVk, IC4x, IC4y, calldataload(add(pubSignals, 96)))
                
                g1_mulAccC(_pVk, IC5x, IC5y, calldataload(add(pubSignals, 128)))
                
                g1_mulAccC(_pVk, IC6x, IC6y, calldataload(add(pubSignals, 160)))
                
                g1_mulAccC(_pVk, IC7x, IC7y, calldataload(add(pubSignals, 192)))
                
                g1_mulAccC(_pVk, IC8x, IC8y, calldataload(add(pubSignals, 224)))
                
                g1_mulAccC(_pVk, IC9x, IC9y, calldataload(add(pubSignals, 256)))
                
                g1_mulAccC(_pVk, IC10x, IC10y, calldataload(add(pubSignals, 288)))
                
                g1_mulAccC(_pVk, IC11x, IC11y, calldataload(add(pubSignals, 320)))
                
                g1_mulAccC(_pVk, IC12x, IC12y, calldataload(add(pubSignals, 352)))
                
                g1_mulAccC(_pVk, IC13x, IC13y, calldataload(add(pubSignals, 384)))
                
                g1_mulAccC(_pVk, IC14x, IC14y, calldataload(add(pubSignals, 416)))
                
                g1_mulAccC(_pVk, IC15x, IC15y, calldataload(add(pubSignals, 448)))
                
                g1_mulAccC(_pVk, IC16x, IC16y, calldataload(add(pubSignals, 480)))
                
                g1_mulAccC(_pVk, IC17x, IC17y, calldataload(add(pubSignals, 512)))
                
                g1_mulAccC(_pVk, IC18x, IC18y, calldataload(add(pubSignals, 544)))
                
                g1_mulAccC(_pVk, IC19x, IC19y, calldataload(add(pubSignals, 576)))
                
                g1_mulAccC(_pVk, IC20x, IC20y, calldataload(add(pubSignals, 608)))
                
                g1_mulAccC(_pVk, IC21x, IC21y, calldataload(add(pubSignals, 640)))
                
                g1_mulAccC(_pVk, IC22x, IC22y, calldataload(add(pubSignals, 672)))
                
                g1_mulAccC(_pVk, IC23x, IC23y, calldataload(add(pubSignals, 704)))
                
                g1_mulAccC(_pVk, IC24x, IC24y, calldataload(add(pubSignals, 736)))
                
                g1_mulAccC(_pVk, IC25x, IC25y, calldataload(add(pubSignals, 768)))
                
                g1_mulAccC(_pVk, IC26x, IC26y, calldataload(add(pubSignals, 800)))
                
                g1_mulAccC(_pVk, IC27x, IC27y, calldataload(add(pubSignals, 832)))
                
                g1_mulAccC(_pVk, IC28x, IC28y, calldataload(add(pubSignals, 864)))
                
                g1_mulAccC(_pVk, IC29x, IC29y, calldataload(add(pubSignals, 896)))
                
                g1_mulAccC(_pVk, IC30x, IC30y, calldataload(add(pubSignals, 928)))
                
                g1_mulAccC(_pVk, IC31x, IC31y, calldataload(add(pubSignals, 960)))
                
                g1_mulAccC(_pVk, IC32x, IC32y, calldataload(add(pubSignals, 992)))
                
                g1_mulAccC(_pVk, IC33x, IC33y, calldataload(add(pubSignals, 1024)))
                
                g1_mulAccC(_pVk, IC34x, IC34y, calldataload(add(pubSignals, 1056)))
                
                g1_mulAccC(_pVk, IC35x, IC35y, calldataload(add(pubSignals, 1088)))
                
                g1_mulAccC(_pVk, IC36x, IC36y, calldataload(add(pubSignals, 1120)))
                

                // -A
                mstore(_pPairing, calldataload(pA))
                mstore(add(_pPairing, 32), mod(sub(q, calldataload(add(pA, 32))), q))

                // B
                mstore(add(_pPairing, 64), calldataload(pB))
                mstore(add(_pPairing, 96), calldataload(add(pB, 32)))
                mstore(add(_pPairing, 128), calldataload(add(pB, 64)))
                mstore(add(_pPairing, 160), calldataload(add(pB, 96)))

                // alpha1
                mstore(add(_pPairing, 192), alphax)
                mstore(add(_pPairing, 224), alphay)

                // beta2
                mstore(add(_pPairing, 256), betax1)
                mstore(add(_pPairing, 288), betax2)
                mstore(add(_pPairing, 320), betay1)
                mstore(add(_pPairing, 352), betay2)

                // vk_x
                mstore(add(_pPairing, 384), mload(add(pMem, pVk)))
                mstore(add(_pPairing, 416), mload(add(pMem, add(pVk, 32))))


                // gamma2
                mstore(add(_pPairing, 448), gammax1)
                mstore(add(_pPairing, 480), gammax2)
                mstore(add(_pPairing, 512), gammay1)
                mstore(add(_pPairing, 544), gammay2)

                // C
                mstore(add(_pPairing, 576), calldataload(pC))
                mstore(add(_pPairing, 608), calldataload(add(pC, 32)))

                // delta2
                mstore(add(_pPairing, 640), deltax1)
                mstore(add(_pPairing, 672), deltax2)
                mstore(add(_pPairing, 704), deltay1)
                mstore(add(_pPairing, 736), deltay2)


                let success := staticcall(sub(gas(), 2000), 8, _pPairing, 768, _pPairing, 0x20)

                isOk := and(success, mload(_pPairing))
            }

            let pMem := mload(0x40)
            mstore(0x40, add(pMem, pLastMem))

            // Validate that all evaluations ∈ F
            
            checkField(calldataload(add(_pubSignals, 0)))
            
            checkField(calldataload(add(_pubSignals, 32)))
            
            checkField(calldataload(add(_pubSignals, 64)))
            
            checkField(calldataload(add(_pubSignals, 96)))
            
            checkField(calldataload(add(_pubSignals, 128)))
            
            checkField(calldataload(add(_pubSignals, 160)))
            
            checkField(calldataload(add(_pubSignals, 192)))
            
            checkField(calldataload(add(_pubSignals, 224)))
            
            checkField(calldataload(add(_pubSignals, 256)))
            
            checkField(calldataload(add(_pubSignals, 288)))
            
            checkField(calldataload(add(_pubSignals, 320)))
            
            checkField(calldataload(add(_pubSignals, 352)))
            
            checkField(calldataload(add(_pubSignals, 384)))
            
            checkField(calldataload(add(_pubSignals, 416)))
            
            checkField(calldataload(add(_pubSignals, 448)))
            
            checkField(calldataload(add(_pubSignals, 480)))
            
            checkField(calldataload(add(_pubSignals, 512)))
            
            checkField(calldataload(add(_pubSignals, 544)))
            
            checkField(calldataload(add(_pubSignals, 576)))
            
            checkField(calldataload(add(_pubSignals, 608)))
            
            checkField(calldataload(add(_pubSignals, 640)))
            
            checkField(calldataload(add(_pubSignals, 672)))
            
            checkField(calldataload(add(_pubSignals, 704)))
            
            checkField(calldataload(add(_pubSignals, 736)))
            
            checkField(calldataload(add(_pubSignals, 768)))
            
            checkField(calldataload(add(_pubSignals, 800)))
            
            checkField(calldataload(add(_pubSignals, 832)))
            
            checkField(calldataload(add(_pubSignals, 864)))
            
            checkField(calldataload(add(_pubSignals, 896)))
            
            checkField(calldataload(add(_pubSignals, 928)))
            
            checkField(calldataload(add(_pubSignals, 960)))
            
            checkField(calldataload(add(_pubSignals, 992)))
            
            checkField(calldataload(add(_pubSignals, 1024)))
            
            checkField(calldataload(add(_pubSignals, 1056)))
            
            checkField(calldataload(add(_pubSignals, 1088)))
            
            checkField(calldataload(add(_pubSignals, 1120)))
            

            // Validate all evaluations
            let isValid := checkPairing(_pA, _pB, _pC, _pubSignals, pMem)

            mstore(0, isValid)
             return(0, 0x20)
         }
     }
 }
