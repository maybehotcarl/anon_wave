// SPDX-License-Identifier: MIT
pragma solidity >=0.8.0 <0.9.0;

/**
 * @title IProofVerifier
 * @notice Common interface for all Groth16 proof verifiers in the 6529 ZK Service.
 *         Each proof type (TDH range, card ownership, etc.) implements this interface
 *         with its own verification key and public signal count.
 */
interface IProofVerifier {
    /**
     * @notice Verify a Groth16 proof
     * @param _pA Proof element A (G1 point)
     * @param _pB Proof element B (G2 point)
     * @param _pC Proof element C (G1 point)
     * @param _pubSignals Public signals array
     * @return True if the proof is valid
     */
    function verifyProof(
        uint[2] calldata _pA,
        uint[2][2] calldata _pB,
        uint[2] calldata _pC,
        uint[] calldata _pubSignals
    ) external view returns (bool);
}
