-- 6529 ZK Service — Multi-proof-type schema
-- All tables are namespaced by proof_type for extensibility.

-- Merkle roots: partitioned by proof_type
CREATE TABLE IF NOT EXISTS zk_merkle_roots (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proof_type TEXT NOT NULL,
    root TEXT NOT NULL,
    depth INTEGER NOT NULL DEFAULT 20,
    entry_count INTEGER NOT NULL,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_zk_merkle_roots_type_created
    ON zk_merkle_roots(proof_type, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_zk_merkle_roots_root
    ON zk_merkle_roots(root);

-- Merkle proofs: keyed by (proof_type, lookup_key, root)
-- A lookup key may have more than one retained proof while roots roll through
-- verifier grace windows.
CREATE TABLE IF NOT EXISTS zk_merkle_proofs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proof_type TEXT NOT NULL,
    lookup_key TEXT NOT NULL,
    leaf TEXT NOT NULL,
    path_elements TEXT[] NOT NULL,
    path_indices INTEGER[] NOT NULL,
    root TEXT NOT NULL,
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

DROP INDEX IF EXISTS idx_zk_merkle_proofs_type_key;

CREATE UNIQUE INDEX IF NOT EXISTS idx_zk_merkle_proofs_type_key_root
    ON zk_merkle_proofs(proof_type, lookup_key, root);
CREATE INDEX IF NOT EXISTS idx_zk_merkle_proofs_type_key
    ON zk_merkle_proofs(proof_type, lookup_key);
CREATE INDEX IF NOT EXISTS idx_zk_merkle_proofs_root
    ON zk_merkle_proofs(root);
CREATE INDEX IF NOT EXISTS idx_zk_merkle_proofs_type_root
    ON zk_merkle_proofs(proof_type, root);

-- Used nullifiers: namespaced by proof_type + app_id
CREATE TABLE IF NOT EXISTS zk_used_nullifiers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    proof_type TEXT NOT NULL,
    app_id TEXT NOT NULL DEFAULT 'default',
    nullifier_hash TEXT NOT NULL,
    commitment_hash TEXT NOT NULL,
    metadata JSONB DEFAULT '{}',
    used_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX IF NOT EXISTS idx_zk_used_nullifiers_unique
    ON zk_used_nullifiers(proof_type, app_id, nullifier_hash);
CREATE INDEX IF NOT EXISTS idx_zk_used_nullifiers_hash
    ON zk_used_nullifiers(nullifier_hash);

-- Sync state per proof type
CREATE TABLE IF NOT EXISTS zk_sync_state (
    proof_type TEXT PRIMARY KEY,
    last_sync_at TIMESTAMPTZ,
    entry_count INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'idle',
    error_message TEXT,
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Row Level Security
ALTER TABLE zk_merkle_roots ENABLE ROW LEVEL SECURITY;
CREATE POLICY "zk_merkle_roots_public_read" ON zk_merkle_roots
    FOR SELECT USING (true);

ALTER TABLE zk_merkle_proofs ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "zk_merkle_proofs_public_read" ON zk_merkle_proofs;

ALTER TABLE zk_used_nullifiers ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS "zk_used_nullifiers_public_read" ON zk_used_nullifiers;

ALTER TABLE zk_sync_state ENABLE ROW LEVEL SECURITY;
CREATE POLICY "zk_sync_state_public_read" ON zk_sync_state
    FOR SELECT USING (true);

-- Dev/issuer source table for published vpn_access_v1 entitlements
CREATE TABLE IF NOT EXISTS zk_vpn_access_entitlements (
    identity_commitment TEXT PRIMARY KEY,
    entitlement_class TEXT NOT NULL,
    expiry_bucket TEXT NOT NULL,
    policy_epoch TEXT NOT NULL,
    schema_version TEXT NOT NULL DEFAULT '1',
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS idx_zk_vpn_access_entitlements_policy_epoch
    ON zk_vpn_access_entitlements(policy_epoch);

ALTER TABLE zk_vpn_access_entitlements ENABLE ROW LEVEL SECURITY;
