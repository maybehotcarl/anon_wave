pragma circom 2.1.0;

// N-of-M Cards Proof Circuit (Test — depth=10, maxSet=32)

include "node_modules/circomlib/circuits/poseidon.circom";
include "node_modules/circomlib/circuits/comparators.circom";
include "node_modules/circomlib/circuits/bitify.circom";
include "../lib/merkle-tree-computer.circom";
include "../lib/set-member-check.circom";

template NOfMCardsProof(merkleDepth, maxSet) {
    signal input merkleRoot;
    signal input threshold;
    signal input nullifierHash;
    signal input commitmentHash;
    signal input cardSet[maxSet];

    signal input address;
    signal input nonce;
    signal input proofCardId[maxSet];
    signal input proofBalance[maxSet];
    signal input proofPathElements[maxSet][merkleDepth];
    signal input proofPathIndices[maxSet][merkleDepth];
    signal input active[maxSet];

    component leafHasher[maxSet];
    component merkleComputer[maxSet];
    component balanceGte[maxSet];
    component setMember[maxSet];

    signal rootDiff[maxSet];
    signal activeRootCheck[maxSet];
    signal activeBalanceCheck[maxSet];
    signal activeSetCheck[maxSet];

    signal activeSum[maxSet + 1];
    activeSum[0] <== 0;

    for (var i = 0; i < maxSet; i++) {
        active[i] * (1 - active[i]) === 0;

        leafHasher[i] = Poseidon(3);
        leafHasher[i].inputs[0] <== address;
        leafHasher[i].inputs[1] <== proofCardId[i];
        leafHasher[i].inputs[2] <== proofBalance[i];

        merkleComputer[i] = MerkleTreeComputer(merkleDepth);
        merkleComputer[i].leaf <== leafHasher[i].out;
        for (var j = 0; j < merkleDepth; j++) {
            merkleComputer[i].pathElements[j] <== proofPathElements[i][j];
            merkleComputer[i].pathIndices[j] <== proofPathIndices[i][j];
        }

        rootDiff[i] <== merkleComputer[i].root - merkleRoot;
        activeRootCheck[i] <== active[i] * rootDiff[i];
        activeRootCheck[i] === 0;

        balanceGte[i] = GreaterEqThan(64);
        balanceGte[i].in[0] <== proofBalance[i];
        balanceGte[i].in[1] <== 1;
        activeBalanceCheck[i] <== active[i] * (balanceGte[i].out - 1);
        activeBalanceCheck[i] === 0;

        setMember[i] = SetMemberCheck(maxSet);
        setMember[i].value <== proofCardId[i];
        for (var k = 0; k < maxSet; k++) {
            setMember[i].set[k] <== cardSet[k];
        }
        activeSetCheck[i] <== active[i] * (setMember[i].isMember - 1);
        activeSetCheck[i] === 0;

        activeSum[i + 1] <== activeSum[i] + active[i];
    }

    activeSum[maxSet] === threshold;

    component pairEq[maxSet * (maxSet - 1) / 2];
    signal pairBothActive[maxSet * (maxSet - 1) / 2];
    signal pairDupeCheck[maxSet * (maxSet - 1) / 2];
    var pairIdx = 0;
    for (var i = 0; i < maxSet; i++) {
        for (var j = i + 1; j < maxSet; j++) {
            pairEq[pairIdx] = IsEqual();
            pairEq[pairIdx].in[0] <== proofCardId[i];
            pairEq[pairIdx].in[1] <== proofCardId[j];

            pairBothActive[pairIdx] <== active[i] * active[j];
            pairDupeCheck[pairIdx] <== pairBothActive[pairIdx] * pairEq[pairIdx].out;
            pairDupeCheck[pairIdx] === 0;

            pairIdx = pairIdx + 1;
        }
    }

    component nullifierGenerator = Poseidon(3);
    nullifierGenerator.inputs[0] <== address;
    nullifierGenerator.inputs[1] <== nonce;
    nullifierGenerator.inputs[2] <== merkleRoot;
    nullifierHash === nullifierGenerator.out;

    component commitmentGenerator = Poseidon(3);
    commitmentGenerator.inputs[0] <== address;
    commitmentGenerator.inputs[1] <== nonce;
    commitmentGenerator.inputs[2] <== threshold;
    commitmentHash === commitmentGenerator.out;
}

component main {public [merkleRoot, threshold, nullifierHash, commitmentHash, cardSet]} = NOfMCardsProof(10, 32);
