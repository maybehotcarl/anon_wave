pragma circom 2.1.0;

// Card Ownership Proof Circuit (Production — depth=20)
//
// Proves "I own card #X from the 6529 meme collection" without revealing
// the wallet address. Supports N-of-M batch proofs via shared batchId.
//
// Public signals (5): merkleRoot, cardId, nullifierHash, commitmentHash, batchId
// Private signals: address, balance, nonce, batchNonce, merklePathElements, merklePathIndices

include "node_modules/circomlib/circuits/poseidon.circom";
include "node_modules/circomlib/circuits/comparators.circom";
include "node_modules/circomlib/circuits/bitify.circom";
include "../lib/merkle-tree-checker.circom";

template CardOwnershipProof(merkleDepth) {
    // PUBLIC INPUTS
    signal input merkleRoot;
    signal input cardId;             // Which card (public — known to verifier)
    signal input nullifierHash;
    signal input commitmentHash;
    signal input batchId;            // Poseidon(address, batchNonce) — ties N-of-M proofs

    // PRIVATE INPUTS
    signal input address;            // Wallet address (field element)
    signal input balance;            // Card balance (must be >= 1)
    signal input nonce;              // Nullifier nonce
    signal input batchNonce;         // Batch nonce for N-of-M
    signal input merklePathElements[merkleDepth];
    signal input merklePathIndices[merkleDepth];

    // 1. Merkle Tree Membership: leaf = Poseidon(address, cardId, balance)
    component leafHasher = Poseidon(3);
    leafHasher.inputs[0] <== address;
    leafHasher.inputs[1] <== cardId;
    leafHasher.inputs[2] <== balance;
    signal leaf <== leafHasher.out;

    component merkleChecker = MerkleTreeChecker(merkleDepth);
    merkleChecker.leaf <== leaf;
    merkleChecker.merkleRoot <== merkleRoot;
    for (var i = 0; i < merkleDepth; i++) {
        merkleChecker.pathElements[i] <== merklePathElements[i];
        merkleChecker.pathIndices[i] <== merklePathIndices[i];
    }

    // 2. Balance >= 1 (must own at least one)
    component gte = GreaterEqThan(64);
    gte.in[0] <== balance;
    gte.in[1] <== 1;
    gte.out === 1;

    // 3. Nullifier: Poseidon(address, cardId, nonce, merkleRoot)
    component nullifierGenerator = Poseidon(4);
    nullifierGenerator.inputs[0] <== address;
    nullifierGenerator.inputs[1] <== cardId;
    nullifierGenerator.inputs[2] <== nonce;
    nullifierGenerator.inputs[3] <== merkleRoot;
    nullifierHash === nullifierGenerator.out;

    // 4. Commitment: Poseidon(address, cardId, balance, nonce)
    component commitmentGenerator = Poseidon(4);
    commitmentGenerator.inputs[0] <== address;
    commitmentGenerator.inputs[1] <== cardId;
    commitmentGenerator.inputs[2] <== balance;
    commitmentGenerator.inputs[3] <== nonce;
    commitmentHash === commitmentGenerator.out;

    // 5. Batch ID: Poseidon(address, batchNonce)
    //    For N-of-M proofs: all proofs from same wallet share this batchId
    //    Verifier checks all proofs have same batchId (same wallet) without knowing wallet
    component batchIdGenerator = Poseidon(2);
    batchIdGenerator.inputs[0] <== address;
    batchIdGenerator.inputs[1] <== batchNonce;
    batchId === batchIdGenerator.out;
}

component main {public [merkleRoot, cardId, nullifierHash, commitmentHash, batchId]} = CardOwnershipProof(20);
