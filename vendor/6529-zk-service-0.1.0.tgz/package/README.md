# 6529 ZK Service SDK

`@6529/zk-service` is the reusable SDK layer for privacy-preserving checks in the
6529 ecosystem. It includes:

- Merkle tree and proof primitives
- Proof-type modules (`tdh_range`, `level_range`, `card_ownership`, `any_card`, `n_of_m_cards`)
- Next.js route factory for hosted APIs
- Browser SDK for client-side prove + server verify flows

## Browser Quickstart

```ts
import { ZKSiteClient } from '@6529/zk-service/browser';

let walletProofJwt: string | null = null;
const zk = new ZKSiteClient({
  apiUrl: 'https://zkyc.solutions',
  artifactBaseUrl: 'https://zkyc.solutions/api/artifacts',
  getAuthToken: () => walletProofJwt,
  timeoutMs: 15000,
  retries: 2,
  retryDelayMs: 250,
});

walletProofJwt = (await zk.getWalletProofToken({
  walletAddress: '0xabc...',
  chainId: 1,
  signMessage: (message) =>
    window.ethereum.request({
      method: 'personal_sign',
      params: [message, '0xabc...'],
    }),
})).token;

const gate = await zk.checkAnyCard({ walletAddress: '0xabc...' });
if (gate.status === 'verified') {
  // allow private path
}
```

6529 level gates use the same plug-and-play flow:

```ts
const gate = await zk.checkLevelRange({
  walletAddress: '0xabc...',
  levelMin: 50,
  levelMax: 100,
});
```

Service metadata discovery:

```ts
const meta = await zk.getServiceMeta();
console.log(meta?.capabilities.proofTypes);
```

## Docs

- Integration quickstart: `docs/integration/plug-and-play-quickstart.md`
- Next.js example component: `examples/nextjs/private-mode-gate.tsx`
- Next.js `vpn_access_v1` dev-registration route: `examples/nextjs/app/api/vpn-access/dev-register/route.ts`
- Release gate workflow notes: `docs/release-gate.md`
- Sovereign VPN paid-anonymous proof spec: `docs/vpn-access-v1.md`

## Development

```bash
npm ci
npm run typecheck
npm run test:unit
npm run build
```
