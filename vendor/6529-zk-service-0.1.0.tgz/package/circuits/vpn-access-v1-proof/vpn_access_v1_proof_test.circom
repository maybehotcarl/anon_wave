pragma circom 2.1.0;

// vpn_access_v1 (Test - depth=10)

include "node_modules/circomlib/circuits/poseidon.circom";
include "../lib/merkle-tree-checker.circom";

template VPNAccessV1Proof(merkleDepth) {
    signal input merkleRoot;
    signal input policyEpoch;
    signal input entitlementClass;
    signal input expiryBucket;
    signal input nullifierHash;
    signal input challengeHash;
    signal input sessionKeyHash;

    signal input identitySecret;
    signal input identitySalt;
    signal input schemaVersion;
    signal input merklePathElements[merkleDepth];
    signal input merklePathIndices[merkleDepth];

    component identityCommitmentHasher = Poseidon(2);
    identityCommitmentHasher.inputs[0] <== identitySecret;
    identityCommitmentHasher.inputs[1] <== identitySalt;
    signal identityCommitment <== identityCommitmentHasher.out;

    component leafHasher = Poseidon(5);
    leafHasher.inputs[0] <== identityCommitment;
    leafHasher.inputs[1] <== entitlementClass;
    leafHasher.inputs[2] <== expiryBucket;
    leafHasher.inputs[3] <== policyEpoch;
    leafHasher.inputs[4] <== schemaVersion;
    signal leaf <== leafHasher.out;

    component merkleChecker = MerkleTreeChecker(merkleDepth);
    merkleChecker.leaf <== leaf;
    merkleChecker.merkleRoot <== merkleRoot;
    for (var i = 0; i < merkleDepth; i++) {
        merkleChecker.pathElements[i] <== merklePathElements[i];
        merkleChecker.pathIndices[i] <== merklePathIndices[i];
    }

    component nullifierGenerator = Poseidon(4);
    nullifierGenerator.inputs[0] <== identitySecret;
    nullifierGenerator.inputs[1] <== identitySalt;
    nullifierGenerator.inputs[2] <== challengeHash;
    nullifierGenerator.inputs[3] <== policyEpoch;
    nullifierHash === nullifierGenerator.out;
}

component main {public [merkleRoot, policyEpoch, entitlementClass, expiryBucket, nullifierHash, challengeHash, sessionKeyHash]} = VPNAccessV1Proof(10);
