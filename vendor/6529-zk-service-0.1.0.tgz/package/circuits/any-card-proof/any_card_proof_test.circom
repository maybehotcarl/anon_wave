pragma circom 2.1.0;

// Any Card Proof Circuit (Test — depth=10, ~1K entries)

include "node_modules/circomlib/circuits/poseidon.circom";
include "node_modules/circomlib/circuits/comparators.circom";
include "node_modules/circomlib/circuits/bitify.circom";
include "../lib/merkle-tree-checker.circom";

template AnyCardProof(merkleDepth) {
    signal input merkleRoot;
    signal input nullifierHash;
    signal input commitmentHash;

    signal input address;
    signal input cardId;
    signal input balance;
    signal input nonce;
    signal input merklePathElements[merkleDepth];
    signal input merklePathIndices[merkleDepth];

    // 1. Leaf = Poseidon(address, cardId, balance)
    component leafHasher = Poseidon(3);
    leafHasher.inputs[0] <== address;
    leafHasher.inputs[1] <== cardId;
    leafHasher.inputs[2] <== balance;
    signal leaf <== leafHasher.out;

    component merkleChecker = MerkleTreeChecker(merkleDepth);
    merkleChecker.leaf <== leaf;
    merkleChecker.merkleRoot <== merkleRoot;
    for (var i = 0; i < merkleDepth; i++) {
        merkleChecker.pathElements[i] <== merklePathElements[i];
        merkleChecker.pathIndices[i] <== merklePathIndices[i];
    }

    // 2. Balance >= 1
    component gte = GreaterEqThan(64);
    gte.in[0] <== balance;
    gte.in[1] <== 1;
    gte.out === 1;

    // 3. Nullifier = Poseidon(address, nonce, merkleRoot)
    component nullifierGenerator = Poseidon(3);
    nullifierGenerator.inputs[0] <== address;
    nullifierGenerator.inputs[1] <== nonce;
    nullifierGenerator.inputs[2] <== merkleRoot;
    nullifierHash === nullifierGenerator.out;

    // 4. Commitment = Poseidon(address, nonce)
    component commitmentGenerator = Poseidon(2);
    commitmentGenerator.inputs[0] <== address;
    commitmentGenerator.inputs[1] <== nonce;
    commitmentHash === commitmentGenerator.out;
}

component main {public [merkleRoot, nullifierHash, commitmentHash]} = AnyCardProof(10);
