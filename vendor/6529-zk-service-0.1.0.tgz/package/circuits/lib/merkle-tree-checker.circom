pragma circom 2.1.0;

include "node_modules/circomlib/circuits/poseidon.circom";

// Merkle tree membership verification using Poseidon hash
// Shared template used by all proof types in the 6529 ZK Service
template MerkleTreeChecker(levels) {
    signal input leaf;
    signal input merkleRoot;
    signal input pathElements[levels];
    signal input pathIndices[levels];

    component hasher[levels];
    signal levelHashes[levels + 1];
    levelHashes[0] <== leaf;

    for (var i = 0; i < levels; i++) {
        // Ensure pathIndices are binary (0 or 1)
        pathIndices[i] * (1 - pathIndices[i]) === 0;

        hasher[i] = Poseidon(2);
        // If pathIndex is 0, leaf is on left, sibling on right
        // If pathIndex is 1, leaf is on right, sibling on left
        hasher[i].inputs[0] <== levelHashes[i] - pathIndices[i] * (levelHashes[i] - pathElements[i]);
        hasher[i].inputs[1] <== pathElements[i] - pathIndices[i] * (pathElements[i] - levelHashes[i]);
        levelHashes[i + 1] <== hasher[i].out;
    }

    // Final hash must equal merkle root
    merkleRoot === levelHashes[levels];
}
