pragma circom 2.1.0;

// Card Ownership Proof Circuit (Test — depth=10, ~1K entries)

include "node_modules/circomlib/circuits/poseidon.circom";
include "node_modules/circomlib/circuits/comparators.circom";
include "node_modules/circomlib/circuits/bitify.circom";
include "../lib/merkle-tree-checker.circom";

template CardOwnershipProof(merkleDepth) {
    signal input merkleRoot;
    signal input cardId;
    signal input nullifierHash;
    signal input commitmentHash;
    signal input batchId;

    signal input address;
    signal input balance;
    signal input nonce;
    signal input batchNonce;
    signal input merklePathElements[merkleDepth];
    signal input merklePathIndices[merkleDepth];

    // 1. Leaf = Poseidon(address, cardId, balance)
    component leafHasher = Poseidon(3);
    leafHasher.inputs[0] <== address;
    leafHasher.inputs[1] <== cardId;
    leafHasher.inputs[2] <== balance;
    signal leaf <== leafHasher.out;

    component merkleChecker = MerkleTreeChecker(merkleDepth);
    merkleChecker.leaf <== leaf;
    merkleChecker.merkleRoot <== merkleRoot;
    for (var i = 0; i < merkleDepth; i++) {
        merkleChecker.pathElements[i] <== merklePathElements[i];
        merkleChecker.pathIndices[i] <== merklePathIndices[i];
    }

    // 2. Balance >= 1
    component gte = GreaterEqThan(64);
    gte.in[0] <== balance;
    gte.in[1] <== 1;
    gte.out === 1;

    // 3. Nullifier = Poseidon(address, cardId, nonce, merkleRoot)
    component nullifierGenerator = Poseidon(4);
    nullifierGenerator.inputs[0] <== address;
    nullifierGenerator.inputs[1] <== cardId;
    nullifierGenerator.inputs[2] <== nonce;
    nullifierGenerator.inputs[3] <== merkleRoot;
    nullifierHash === nullifierGenerator.out;

    // 4. Commitment = Poseidon(address, cardId, balance, nonce)
    component commitmentGenerator = Poseidon(4);
    commitmentGenerator.inputs[0] <== address;
    commitmentGenerator.inputs[1] <== cardId;
    commitmentGenerator.inputs[2] <== balance;
    commitmentGenerator.inputs[3] <== nonce;
    commitmentHash === commitmentGenerator.out;

    // 5. BatchId = Poseidon(address, batchNonce)
    component batchIdGenerator = Poseidon(2);
    batchIdGenerator.inputs[0] <== address;
    batchIdGenerator.inputs[1] <== batchNonce;
    batchId === batchIdGenerator.out;
}

component main {public [merkleRoot, cardId, nullifierHash, commitmentHash, batchId]} = CardOwnershipProof(10);
