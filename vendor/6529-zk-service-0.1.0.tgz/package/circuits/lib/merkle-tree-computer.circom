pragma circom 2.1.0;

include "node_modules/circomlib/circuits/poseidon.circom";

// Merkle tree root computation WITHOUT assertion
// Computes the root from a leaf and path, outputting the result.
// Used when inclusion needs to be checked conditionally (e.g. n_of_m_cards).
template MerkleTreeComputer(levels) {
    signal input leaf;
    signal input pathElements[levels];
    signal input pathIndices[levels];
    signal output root;

    component hasher[levels];
    signal levelHashes[levels + 1];
    levelHashes[0] <== leaf;

    for (var i = 0; i < levels; i++) {
        // Ensure pathIndices are binary (0 or 1)
        pathIndices[i] * (1 - pathIndices[i]) === 0;

        hasher[i] = Poseidon(2);
        hasher[i].inputs[0] <== levelHashes[i] - pathIndices[i] * (levelHashes[i] - pathElements[i]);
        hasher[i].inputs[1] <== pathElements[i] - pathIndices[i] * (pathElements[i] - levelHashes[i]);
        levelHashes[i + 1] <== hasher[i].out;
    }

    root <== levelHashes[levels];
}
