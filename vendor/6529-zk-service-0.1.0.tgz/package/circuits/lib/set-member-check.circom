pragma circom 2.1.0;

include "node_modules/circomlib/circuits/comparators.circom";

// Check if a value is a member of a fixed-size set.
// Output is 1 if value matches any element in the set, 0 otherwise.
template SetMemberCheck(setSize) {
    signal input value;
    signal input set[setSize];
    signal output isMember;

    component eq[setSize];
    signal partial[setSize + 1];
    partial[0] <== 0;

    for (var i = 0; i < setSize; i++) {
        eq[i] = IsEqual();
        eq[i].in[0] <== value;
        eq[i].in[1] <== set[i];
        // Accumulate: if any match, sum > 0
        partial[i + 1] <== partial[i] + eq[i].out;
    }

    // isMember = 1 if partial[setSize] > 0, else 0
    component isPositive = IsZero();
    isPositive.in <== partial[setSize];
    isMember <== 1 - isPositive.out;
}
