pragma circom 2.1.0;

include "node_modules/circomlib/circuits/comparators.circom";

// Range proof — verify value is within [min, max]
// Shared template used by proof types that need range checks
template RangeProof(n) {
    signal input in;
    signal input min;
    signal input max;
    signal output out;

    component gte = GreaterEqThan(n);
    gte.in[0] <== in;
    gte.in[1] <== min;

    component lte = LessEqThan(n);
    lte.in[0] <== in;
    lte.in[1] <== max;

    // Both conditions must be true
    out <== gte.out * lte.out;
}
